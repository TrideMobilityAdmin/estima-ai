
begin
    using CSV, DataFrames, Transformers, Transformers.TextEncoders, Transformers.HuggingFace
    using LinearAlgebra, Statistics, TextAnalysis, Clustering, Distances
    using Plots, StatsBase, JLD2
    using Mongoc
end
# First, create a function to safely transform the DataFrame
function prepare_df_for_csv(df::DataFrame)
    # Create a copy to avoid modifying the original
    export_df = copy(df)
    
    # Replace nothing with missing in all columns
    for col in names(export_df)
        # Skip if column is all numbers
        if eltype(export_df[!, col]) <: Number
            continue
        end
        # Replace nothing with missing
        export_df[!, col] = coalesce.(export_df[!, col], missing)
    end
    
    return export_df
end

# Function to safely write DataFrame to CSV
function safe_write_csv(df::DataFrame, filepath::String)
    try
        # Prepare the DataFrame
        export_df = prepare_df_for_csv(df)
        
        # Write to CSV with options to handle missing values
        CSV.write(
            filepath,
            export_df,
            transform=(col, val) -> something(val, missing),
            missingstring="NA"
        )
        
        println("Successfully wrote DataFrame to $filepath")
        return true
    catch e
        println("Error writing CSV: ", e)
        return false
    end
end

function get_mongodb_data(collection_name::String, batch_size::Int=1000)
    client = Mongoc.Client("mongodb://admin:Tride%401234@telematics-mongo1.evrides.in:22022,telematics-mongo2.evrides.in:22022,telematics-mongo3.evrides.in:22022/?authSource=admin&replicaSet=trideRepl")
    db = client["gmr-mro-test"]
    collection = db[collection_name]

    # Create an empty BSON query document
    query = Mongoc.BSON("{}")
    
    cursor = Mongoc.find(collection, query)
    data_chunks = DataFrame[]
    total_docs = 0

    try
        batch = []
        cursor_state = nothing

        while true
            # Get next document using iterator protocol
            iter_result = iterate(cursor, cursor_state)
            
            if isnothing(iter_result)
                # No more documents
                if !isempty(batch)
                    push!(data_chunks, DataFrame(batch))
                end
                break
            end

            doc, cursor_state = iter_result
            # Convert BSON to Dict before pushing
            push!(batch, Dict(String(k) => v for (k,v) in pairs(doc)))
            total_docs += 1

            if length(batch) >= batch_size
                push!(data_chunks, DataFrame(batch))
                batch = []
            end
        end
    finally
        Mongoc.destroy!(cursor)
    end
    
    println("Total documents retrieved: $total_docs")
    
    if isempty(data_chunks)
        return DataFrame()
    end
    
    return vcat(data_chunks...)  # Concatenate all chunks into one DataFrame
end
begin
    sub_task_parts = get_mongodb_data("sub_task_parts", 1000)
    sub_task_description = get_mongodb_data("sub_task_description", 1000)
    task_description = get_mongodb_data("task_description", 1000)
    aircraft_details = get_mongodb_data("aircraft_details", 1000)
end
# Function to find the most frequent value safely
function most_frequent(x)
    x_clean = skipmissing(x)  # Remove missing values
    counts = countmap(x_clean)  # Count occurrences
    return isempty(counts) ? missing : argmax(counts)  # Return the most frequent
end

# Function to safely compute mean, ignoring invalid values
function safe_mean(x)
    x_numeric = filter(v -> v isa Number, skipmissing(x))  # Remove missing & non-numeric values
    return isempty(x_numeric) ? missing : mean(x_numeric)
end
function aggregate_sub_task_parts(sub_task_parts::DataFrame)
    # Define numeric columns
    numeric_cols = ["freight_cost", "admin_charges", "base_price_usd"]
    
    # Convert Nothing to missing and remove invalid string entries
    for col in numeric_cols
        if col in names(sub_task_parts)
            sub_task_parts[!, col] = map(x -> x isa Number ? x : missing, sub_task_parts[!, col])  # Keep only numbers
        end
    end

    # Handle possible missing part descriptions and units safely
    most_frequent_safe = x -> isempty(x) ? missing : most_frequent(x)

    grouped_df = combine(groupby(sub_task_parts, "issued_part_number"),
        "part_description" => most_frequent_safe => "part_description",
        "issued_unit_of_measurement" => most_frequent_safe => "issued_unit_of_measurement",
        "freight_cost" => safe_mean => "freight_cost",
        "admin_charges" => safe_mean => "admin_charges",
        "base_price_usd" => safe_mean => "base_price_usd"
    )
    
    # Replace any remaining missing values with 0.0
    for col in numeric_cols
        if col in names(grouped_df)
            grouped_df[!, col] = coalesce.(grouped_df[!, col], 0.0)
        end
    end
    
    return grouped_df
end
function create_partval_emb(col, sub_task_parts, part_index)
    # Initialize column for embeddings in df
    partval = [zeros(Float64, length(part_index)) for _ in 1:length(col)]
    
    for (i, task_num) in enumerate(col)
        if ismissing(task_num) || task_num === nothing  # Skip invalid task numbers
            continue
        end

        # Lookup rows in sub_task_parts where "task_number" matches "discrepancy_number"
        matching_rows = filter(r -> !ismissing(r."task_number") && r."task_number" == task_num, sub_task_parts)

        embedding_vector = zeros(Float64, length(part_index))

        for match in eachrow(matching_rows)
            part = match."issued_part_number"
            base_price = coalesce(match."base_price_usd", 0.0)  # Convert missing/Nothing to 0.0
            quantity = coalesce(match."used_quantity", 0.0)  # Convert missing/Nothing to 0.0

            if part in keys(part_index)
                embedding_vector[part_index[part]] += base_price * quantity
            end
        end

        partval[i] = embedding_vector  # Store unique embedding per row
    end

    return partval
end
function split_and_trim(s)
    return first(split(strip(something(s, "")), "\n"))
end
# Function 1: Train on a DataFrame column of texts.
# Input: a DataFrame and the Symbol for the text column.
# Output: a NamedTuple containing the learned lexicon, idf vector, and training embeddings.
function train_embeddings(text_col)
    # Extract texts from the DataFrame column
    texts = Vector{String}(split_and_trim.(text_col))
    # Build a corpus from the training texts and update its lexicon.
    corpus = Corpus(StringDocument.(texts))
    update_lexicon!(corpus)
    lex = lexicon(corpus)
    # Create a Document Term Matrix from the corpus.
    dtm_train = DocumentTermMatrix(corpus)
    # Compute the TF-IDF matrix for the training texts.
    tfidf_train = tf_idf(dtm_train)
    # Compute an idf vector.
    # n_docs is the number of documents in the training corpus.
    n_docs = size(dtm(dtm_train),1)
    # Count how many documents contain each term.
    # (dtm_train .> 0) returns a boolean matrix; summing along the rows gives 	document frequency.
    doc_freq = sum(dtm(dtm_train) .> 0, dims=1)
    # Compute idf as: log(total_docs / (doc_frequency + 1)) to smooth zero counts.
    idf_vector = log.(n_docs ./ (doc_freq .+ 1))
    embs = [tfidf_train[i, :] for i in 1:size(tfidf_train, 1)]
    return embs, (lexicon = lex, idf = idf_vector, training_embeddings = tfidf_train)
end

function cosine_similarity(vec1, vec2)
    return dot(vec1, vec2) / (norm(vec1) * norm(vec2))
end

function safe_convert_to_float(value)
    if value === nothing || ismissing(value)
        return 0.0  # Replace `nothing` or `missing` with 0.0
    elseif value isa AbstractString
        try
            return parse(Float64, value)  # Convert valid numeric strings
        catch
            @warn "Non-numeric string '$value' found. Defaulting to 0.0."
            return 0.0  # Default to 0.0 if conversion fails
        end
    elseif value isa Number
        return Float64(value)  # Convert numbers safely
    else
        @warn "Unexpected type $(typeof(value)) found. Defaulting to 0.0."
        return 0.0  # Default for unexpected types
    end
end

function incremental_clustering(df::DataFrame, similarity_threshold::Float64 = 0.87)
    clusters = DataFrame(
        cluster_id = Int[], 
        avg_emb = Vector{Vector{Float64}}(), 
        pvh = Vector{Vector{Vector{Float64}}}(), 
        amh = Vector{Float64}[],  # Changed to Vector{Float64}[] to store vectors of floats
        nh = Int[]
    )
    
    cluster_assignments = fill(0, nrow(df))
    
    for i in 1:nrow(df)
        embedding = df.embs[i]
        assigned = false
        
        # Safely convert actual_man_hours to Float64
        actual_man_hours_value = safe_convert_to_float(df.actual_man_hours[i])
        
        # Check similarity with existing clusters
        for j in 1:nrow(clusters)
            if cosine_similarity(embedding, clusters.avg_emb[j]) ≥ similarity_threshold
                cluster_assignments[i] = clusters.cluster_id[j]
                
                # Update cluster centroid (running average)
                nmem = sum(cluster_assignments .== clusters.cluster_id[j])
                clusters.avg_emb[j] .= ((clusters.avg_emb[j] * (nmem - 1)) + embedding) / nmem
                
                # Update cluster statistics
                push!(clusters.pvh[j], df.partval[i])
                push!(clusters.amh[j], actual_man_hours_value)  # Don't wrap in extra vector
                clusters.nh[j] = nmem
                assigned = true
                break
            end
        end
        
        # If not assigned, create a new cluster
        if !assigned
            new_cluster_id = nrow(clusters) + 1
            push!(clusters, (
                new_cluster_id, 
                embedding, 
                [df.partval[i]], 
                [actual_man_hours_value],  # Single vector of Float64
                1
            ))
            cluster_assignments[i] = new_cluster_id
        end
    end
    
    df.cluster = cluster_assignments
    return clusters
end
function dbscan_clustering_while_mutating_df(df::DataFrame, eps::Float64=0.1, min_pts::Int=2)
    embeddings = reduce(hcat, df.partval)' # embs in (num_samples, num_features)
	cosine_dist_matrix = pairwise(CosineDist(), embeddings', dims=2)
    # Perform DBSCAN clustering
    result = dbscan(cosine_dist_matrix, eps, min_pts)
    df.cluster = result.assignments
	cluster_ids = unique(result.assignments)
	clusters = DataFrame(cluster_id = Int[], avg_emb = Vector{Vector{Float64}}(), pvh = Vector{Vector{Vector{Float64}}}(), amh = Vector{Vector{Float64}}(), nh = Int[])
    
    for cluster_id in cluster_ids
        if cluster_id != 0  # Ignore noise points
            cluster_rows = findall(==(cluster_id), result.assignments)
            avg_embedding = mean(embeddings[cluster_rows, :], dims=1) |> vec
			rows = filter(:cluster => ==(cluster_id), df)
            push!(clusters, (cluster_id, avg_embedding, rows.partval, rows."actual_man_hours",nrow(rows)))
        end
    end

    return clusters
end

function create_the_co_occurrence_matrix(sub_task_description, task_description, task_clusters, disc_clusters)
	jdf = select(innerjoin(sub_task_description, task_description, on = Symbol("source_task_discrepancy_number") => Symbol("task_number"), matchmissing = :notequal, makeunique=true),:cluster,:cluster_1)
	gdf=combine(groupby(jdf, [:cluster, :cluster_1]), nrow => :count)
    # Extract unique cluster IDs
    col_ids = unique(task_clusters.cluster_id)
    row_ids = unique(disc_clusters.cluster_id)

    # Create all possible (cluster_f, cluster) pairs
    all_combinations = DataFrame(cluster=repeat(row_ids, inner=length(col_ids)),
                                 cluster_1=repeat(col_ids, outer=length(row_ids)))

    # Left join with grouped_df to get actual counts, fill missing with 0
    merged_df = leftjoin(all_combinations, gdf, on=["cluster", "cluster_1"])
	sort!(merged_df, [:cluster, :cluster_1])
    merged_df.count .= coalesce.(merged_df.count, 0)

    # Pivot the data into matrix form
    pivot_df = unstack(merged_df, :cluster, :cluster_1, :count, fill=0)
	
    # Convert to 2D array (exclude first column with row labels)
    coom = Matrix(pivot_df[:, 2:end])

    return coom
end
function parts_prep(sub_task_parts, sub_task_description, task_description)
    parts = aggregate_sub_task_parts(sub_task_parts)
    part_index = Dict(parts."issued_part_number" .=> eachindex(parts."issued_part_number"))
    
    # Ensure safe numeric computations
    part_price = coalesce.(parts."freight_cost", 0.0) .+ coalesce.(parts."admin_charges", 0.0) .+ coalesce.(parts."base_price_usd", 0.0)
    
    sub_task_description.partval = create_partval_emb(sub_task_description."source_task_discrepancy_number", sub_task_parts, part_index)
    task_description.partval = create_partval_emb(task_description."task_number", sub_task_parts, part_index)

    return parts, part_index, part_price, sub_task_description, task_description
end


function train(sub_task_descriptionv, task_descriptionv)
    task_descriptionv.embs, training_outcomes = train_embeddings(task_descriptionv.description)
    task_clusters = incremental_clustering(task_descriptionv)
    disc_clusters = dbscan_clustering_while_mutating_df(sub_task_descriptionv)
    coom = create_the_co_occurrence_matrix(sub_task_descriptionv, task_descriptionv, task_clusters, disc_clusters)
    return task_clusters, disc_clusters, coom, training_outcomes
end

parts, part_index, part_price, sub_task_descriptionv, task_descriptionv = parts_prep(sub_task_parts, sub_task_description, task_description)
begin
    safe_write_csv(parts, "/home/Data/trainings/1ytrainings/parts.csv")
	jldsave("/home/Data/trainings/1ytrainings/part_price.jld2"; part_price)
end
begin

    # Destroy the variables
    parts = nothing
    part_price = nothing

    # Force garbage collection
    GC.gc()
end

taskc, discc, coom, train_outs = train(sub_task_descriptionv, task_descriptionv)
begin
    #safe_write_csv(parts, "/home/Data/trainings/5ytrainings/parts.csv")
	#jldsave("/home/Data/trainings/5ytrainings/part_price.jld2"; part_price)
	jldsave("/home/Data/trainings/5ytrainings/disc_clusters.jld2"; discc)
	jldsave("/home/Data/trainings/5ytrainings/task_clusters.jld2"; taskc)
	jldsave("/home/Data/trainings/5ytrainings/coom.jld2"; coom)
	jldsave("/home/Data/trainings/5ytrainings/lexicon.jld2";train_outs.lexicon)
	jldsave("/home/Data/trainings/5ytrainings/idf.jld2";train_outs.idf)
	jldsave("/home/Data/trainings/5ytrainings/training_embeddings.jld2";train_outs.training_embeddings)
end